from abc import ABC, abstractmethod


class FormulaTeam(ABC):
    BUDGET_NEEDED = 1_000_000
    def __init__(self, budget:int):
        self.budget = budget

    @property
    @abstractmethod
    def team_data(self):
        pass

    @property
    def budget(self):
        return self.__budget
    
    @budget.setter
    def budget(self, value):
        if value < self.BUDGET_NEEDED:
            raise ValueError("F1 is an expensive sport, find more sponsors!")
        self.__budget = value

    def calculate_revenue_after_race(self, race_pos: int):
        sponsors, expenses = self.team_data
        revenue = 0

        for sponsor in sponsors.values():
            for position, money in sponsor.items():
                if race_pos <= position:
                    revenue += money
                    break

        revenue -= expenses
        self.budget += revenue

        return f"The revenue after the race is {revenue}$. Current budget {self.budget}$"
